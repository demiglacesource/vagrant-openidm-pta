
/*global source */

(function () {
	var map = {"_queryFilter": 'name eq "' + source.userName + '"'};
    
    return map;
}());