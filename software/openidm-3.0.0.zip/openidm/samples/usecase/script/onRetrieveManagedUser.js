/*global object */

object.active = (object.accountStatus.toLowerCase() === 'active');