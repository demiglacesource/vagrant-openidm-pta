/*global source */

(function () {
    var accounts = [];
    if (source.employeeType === 'employee') {
        accounts = ["Business"];
    }
    return accounts;
}());
